Submission for the first project for the Cloud DevOps Nanodegree (Deploy Static Website on AWS):


The url for the for the website: https://df1la1v0sfv81.cloudfront.net/index.html


The screenshots for each required step in the project are available in the 'screenshots' folder. 
